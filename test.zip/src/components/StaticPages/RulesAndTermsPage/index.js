import React from 'react';
import './RulesAndTermsPage.css';
import MainPageHeader from '../../MainPageComponents/MainPageHeader';
import MainPageFooter from '../../MainPageComponents/MainPageFooter';

const RulesAndTermsPage = () => {
  return (
    <div >
      <MainPageHeader/>
        Правила та умови
      <MainPageFooter/>
    </div >
  );
}

export default RulesAndTermsPage;
